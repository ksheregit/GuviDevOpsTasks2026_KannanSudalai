provider "aws" {
  region = "ap-south-1"
}

provider "aws" {
  alias  = "singapore"
  region = "ap-southeast-1"
}

data "aws_ami" "mumbai" {
  most_recent = true
  owners      = ["amazon"]
  filter {
    name   = "name"
    values = ["al2023-ami-2023.*-x86_64"]
  }
}

data "aws_ami" "singapore" {
  provider    = aws.singapore
  most_recent = true
  owners      = ["amazon"]
  filter {
    name   = "name"
    values = ["al2023-ami-2023.*-x86_64"]
  }
}

resource "aws_security_group" "web_mumbai" {
  name        = "tf-web-mumbai"
  description = "Allow HTTP"

  ingress {
    from_port   = 80
    to_port     = 80
    protocol    = "tcp"
    cidr_blocks = ["0.0.0.0/0"]
  }

  egress {
    from_port   = 0
    to_port     = 0
    protocol    = "-1"
    cidr_blocks = ["0.0.0.0/0"]
  }
}

resource "aws_security_group" "web_singapore" {
  provider    = aws.singapore
  name        = "tf-web-singapore"
  description = "Allow HTTP"

  ingress {
    from_port   = 80
    to_port     = 80
    protocol    = "tcp"
    cidr_blocks = ["0.0.0.0/0"]
  }

  egress {
    from_port   = 0
    to_port     = 0
    protocol    = "-1"
    cidr_blocks = ["0.0.0.0/0"]
  }
}

resource "aws_instance" "mumbai" {
  ami                    = data.aws_ami.mumbai.id
  instance_type          = "t3.micro"
  vpc_security_group_ids = [aws_security_group.web_mumbai.id]

  user_data = <<-EOF
    #!/bin/bash
    dnf install -y nginx
    echo "<h1>Nginx on Mumbai (ap-south-1) via Terraform</h1>" > /usr/share/nginx/html/index.html
    systemctl enable --now nginx
  EOF

  tags = { Name = "tf-nginx-mumbai" }
}

resource "aws_instance" "singapore" {
  provider               = aws.singapore
  ami                    = data.aws_ami.singapore.id
  instance_type          = "t3.micro"
  vpc_security_group_ids = [aws_security_group.web_singapore.id]

  user_data = <<-EOF
    #!/bin/bash
    dnf install -y nginx
    echo "<h1>Nginx on Singapore (ap-southeast-1) via Terraform</h1>" > /usr/share/nginx/html/index.html
    systemctl enable --now nginx
  EOF

  tags = { Name = "tf-nginx-singapore" }
}

output "mumbai_url" {
  value = "http://${aws_instance.mumbai.public_ip}"
}

output "singapore_url" {
  value = "http://${aws_instance.singapore.public_ip}"
}
