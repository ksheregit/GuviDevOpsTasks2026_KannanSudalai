provider "aws" {
  region = "ap-south-1"
}

provider "aws" {
  alias  = "singapore"
  region = "ap-southeast-1"
}

data "aws_ami" "mumbai" {
  most_recent = true
  owners      = ["amazon"]
  filter {
    name   = "name"
    values = ["al2023-ami-2023.*-x86_64"]
  }
}

data "aws_ami" "singapore" {
  provider    = aws.singapore
  most_recent = true
  owners      = ["amazon"]
  filter {
    name   = "name"
    values = ["al2023-ami-2023.*-x86_64"]
  }
}

resource "aws_instance" "mumbai" {
  ami           = data.aws_ami.mumbai.id
  instance_type = "t3.micro"
  tags          = { Name = "tf-mumbai" }
}

resource "aws_instance" "singapore" {
  provider      = aws.singapore
  ami           = data.aws_ami.singapore.id
  instance_type = "t3.micro"
  tags          = { Name = "tf-singapore" }
}

output "mumbai_ip" {
  value = aws_instance.mumbai.public_ip
}

output "singapore_ip" {
  value = aws_instance.singapore.public_ip
}
